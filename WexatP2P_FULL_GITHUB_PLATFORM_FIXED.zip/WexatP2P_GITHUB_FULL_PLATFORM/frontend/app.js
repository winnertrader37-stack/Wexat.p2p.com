
const API_BASE = (()=>{const v=(localStorage.getItem('wexat_api') || window.WEXAT_API_BASE || '').trim().replace(/\/$/,''); return v ? (v.endsWith('/api')?v:v+'/api') : '/api';})();

const state = {
  route: location.hash.replace('#','') || 'home',
  offers: [],
  trades: JSON.parse(localStorage.getItem('wexat_trades') || '[]'),
  wallet: {USDT:1250.50, ETB:84500},
  user: JSON.parse(localStorage.getItem('wexat_user') || 'null'),
  filters: {side:'SELL',asset:'USDT',fiat:'ETB',paymentMethod:''}
};

const sampleOffers = [
 {id:'off-1001',side:'SELL',asset:'USDT',fiat:'ETB',price:158.20,min:500,max:50000,available:1200,paymentMethod:'Telebirr',owner:'Verified Merchant'},
 {id:'off-1002',side:'SELL',asset:'USDT',fiat:'ETB',price:159.10,min:1000,max:100000,available:2500,paymentMethod:'Bank Transfer',owner:'Power Merchant'},
 {id:'off-1003',side:'BUY',asset:'USDT',fiat:'ETB',price:157.80,min:500,max:30000,available:900,paymentMethod:'CBE Birr',owner:'Verified Buyer'}
];

function save(){localStorage.setItem('wexat_trades',JSON.stringify(state.trades));localStorage.setItem('wexat_user',JSON.stringify(state.user))}
function money(n,cur='ETB'){return `${Number(n||0).toLocaleString(undefined,{maximumFractionDigits:2})} ${cur}`}
function esc(x){return String(x??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}
function go(r){location.hash=r}
async function api(path,opt={}){const token=state.user?.token;const headers={'Content-Type':'application/json',...(opt.headers||{})};if(token)headers.Authorization=`Bearer ${token}`;const r=await fetch(API_BASE+path,{...opt,headers});if(!r.ok)throw new Error((await r.json().catch(()=>({}))).error||`HTTP ${r.status}`);return r.json()}

async function loadOffers(){
 try{const q=new URLSearchParams(Object.entries(state.filters).filter(([,v])=>v));const x=await api('/offers?'+q);state.offers=x.offers}
 catch{state.offers=sampleOffers.filter(o=>o.side===state.filters.side)}
}

function nav(){
 return `<header class="top"><nav class="nav"><div class="logo" onclick="go('home')" style="cursor:pointer">Wexat<span>P2P</span></div>
 <div class="navlinks">
 ${['home','buy','sell','offers','trades','wallet','kyc','security','support'].map(x=>`<button onclick="go('${x}')">${x[0].toUpperCase()+x.slice(1)}</button>`).join('')}
 ${state.user?.role==='ADMIN'?`<button onclick="go('admin')">Admin</button>`:''}
 </div><div class="spacer"></div>
 ${state.user?`<button class="ghost" onclick="go('profile')">${esc(state.user.fullName||'Account')}</button><button class="btn danger" onclick="logout()">Logout</button>`:`<button class="ghost" onclick="authModal('login')">Login</button><button class="btn primary" onclick="authModal('signup')">Create account</button>`}
 </nav></header>`
}

function home(){
 return `<main class="container"><section class="hero"><div class="card"><span class="badge">SECURE P2P MARKETPLACE</span><h1>Trade directly.<br><span style="color:var(--brand)">Control your money.</span></h1><p>Buy and sell digital assets with transparent offers, escrow-oriented trade states, identity verification workflows, dispute protection and a full admin control layer.</p><div class="actions"><button class="btn primary" onclick="go('buy')">Buy USDT</button><button class="btn secondary" onclick="go('sell')">Sell USDT</button></div></div>
 <div class="card"><h3>Why WexatP2P?</h3><div class="notice success">✓ Offer limits and fees are calculated before confirmation.</div><div class="notice success">✓ Trade status is controlled by server-side rules.</div><div class="notice success">✓ KYC verification is not faked in the browser.</div><div class="notice warning">⚠ Production payments and KYC require configured providers.</div></div></section>
 <section class="section grid4">${[['24/7','Marketplace'],['Escrow','Trade flow'],['KYC','Identity layer'],['Audit','Admin controls']].map(x=>`<div class="card"><div class="stat">${x[0]}</div><div class="muted">${x[1]}</div></div>`).join('')}</section>
 <section class="section card"><h2>How a trade works</h2><div class="grid">${[['1','Choose offer'],['2','Enter amount'],['3','Fund escrow'],['4','Pay seller'],['5','Confirm payment'],['6','Release asset']].map(x=>`<div class="notice"><b>${x[0]}</b> — ${x[1]}</div>`).join('')}</div></section></main>`
}

function marketplace(side){
 state.filters.side=side;loadOffers().then(render);
 return `<main class="container"><div class="card"><span class="badge">${side==='SELL'?'BUY FROM SELLERS':'SELL TO BUYERS'}</span><h1>${side==='SELL'?'Buy':'Sell'} USDT</h1><p class="muted">Filter real offer fields, compare limits and start a protected trade.</p>
 <div class="filters"><select id="assetFilter"><option>USDT</option><option>BTC</option><option>ETH</option></select><select id="paymentFilter"><option value="">All payment methods</option><option>Telebirr</option><option>Bank Transfer</option><option>CBE Birr</option></select><button class="btn primary" onclick="applyFilters()">Apply</button></div>
 <div id="offerList">${offerRows()}</div></div></main>`
}

function offerRows(){
 const data=state.offers.filter(o=>o.side===state.filters.side);
 if(!data.length)return `<div class="notice warning">No matching offers yet.</div>`;
 return `<div class="tablewrap"><table class="table"><thead><tr><th>Merchant</th><th>Price</th><th>Limits</th><th>Available</th><th>Payment</th><th></th></tr></thead><tbody>${data.map(o=>`<tr><td><b>${esc(o.owner||'Merchant')}</b><br><span class="pill">Verified</span></td><td>${money(o.price,'ETB')}/USDT</td><td>${money(o.min)} – ${money(o.max)}</td><td>${o.available} USDT</td><td>${esc(o.paymentMethod)}</td><td><button class="btn primary" onclick="startTrade('${o.id}')">${state.filters.side==='SELL'?'Buy':'Sell'}</button></td></tr>`).join('')}</tbody></table></div>`
}

function offersPage(){
 return `<main class="container"><div class="card"><h1>My Offers</h1><p class="muted">Create, pause and manage your own marketplace offers.</p><button class="btn primary" onclick="offerModal()">Create offer</button><div class="section tablewrap"><table class="table"><thead><tr><th>Side</th><th>Asset</th><th>Price</th><th>Limits</th><th>Payment</th><th>Status</th></tr></thead><tbody>${sampleOffers.map(o=>`<tr><td>${o.side}</td><td>${o.asset}/${o.fiat}</td><td>${money(o.price,o.fiat)}</td><td>${money(o.min)} - ${money(o.max)}</td><td>${o.paymentMethod}</td><td><span class="pill">${o.active?'ACTIVE':'PAUSED'}</span></td></tr>`).join('')}</tbody></table></div></div></main>`
}

function tradesPage(){
 return `<main class="container"><div class="card"><h1>My Trades</h1><p class="muted">Every trade has a state. Actions become available according to that state.</p>${state.trades.length?state.trades.map(t=>`<div class="notice"><b>${t.id}</b> · ${t.status}<br>${money(t.tradeValue)} · ${t.assetAmount} ${t.asset}<div class="actions" style="margin-top:8px">${tradeButtons(t)}</div></div>`).join(''):`<div class="notice">No trades yet. Choose an offer to start.</div>`}</div></main>`
}
function tradeButtons(t){
 const map={CREATED:[['Fund escrow','FUNDED']],FUNDED:[['I sent payment','PAYMENT_SENT']],PAYMENT_SENT:[['Confirm payment','PAYMENT_CONFIRMED']],PAYMENT_CONFIRMED:[['Release asset','RELEASED']]};
 return (map[t.status]||[]).map(x=>`<button class="btn primary" onclick="advanceTrade('${t.id}','${x[1]}')">${x[0]}</button>`).join('')+`<button class="btn danger" onclick="openDispute('${t.id}')">Dispute</button>`
}
function walletPage(){
 return `<main class="container"><div class="grid4">${Object.entries(state.wallet).map(([k,v])=>`<div class="card"><div class="muted">${k}</div><div class="stat">${money(v,k)}</div></div>`).join('')}</div><div class="section grid"><div class="card"><h2>Deposit</h2><p class="muted">Connect a payment provider in production.</p><button class="btn primary" onclick="toast('Deposit workflow requires a configured payment provider.')">Deposit</button></div><div class="card"><h2>Withdraw</h2><p class="muted">Balance, limits, KYC and risk checks must be server-side.</p><button class="btn secondary" onclick="toast('Withdrawal workflow requires a configured payment provider.')">Withdraw</button></div><div class="card"><h2>Ledger</h2><p class="muted">All balance changes should use immutable ledger entries.</p><button class="btn ghost" onclick="toast('Ledger history will load from the API.')">View history</button></div></div></main>`
}
function kycPage(){
 return `<main class="container"><div class="grid"><div class="card"><span class="badge">IDENTITY</span><h1>KYC & National ID</h1><p class="muted">Submit your identity information for provider or compliance review.</p><div class="notice warning">National ID verification is performed by an approved backend provider or authorized manual review. This site never declares an ID verified from browser input alone.</div><button class="btn primary" onclick="kycModal()">Start KYC</button></div><div class="card"><h2>Status</h2><div class="stat">NOT STARTED</div><p class="muted">Complete identity proofing before restricted features are enabled.</p></div></div></main>`
}
function securityPage(){
 return `<main class="container"><div class="card"><h1>Security</h1><div class="grid">${[['2FA','Protect login and withdrawals'],['Sessions','Review active devices'],['Password','Change credentials securely'],['Risk checks','Suspicious activity controls']].map(x=>`<div class="notice success"><b>${x[0]}</b><br>${x[1]}</div>`).join('')}</div></div></main>`
}
function supportPage(){
 return `<main class="container"><div class="grid"><div class="card"><h1>Help Center</h1><p class="muted">Trade, wallet, KYC and account help.</p><div class="notice">How does escrow work?</div><div class="notice">What if the buyer does not pay?</div><div class="notice">How is KYC reviewed?</div></div><div class="card"><h1>Support</h1><div class="field"><label>Issue</label><textarea id="supportText" rows="5"></textarea></div><button class="btn primary" onclick="toast('Support ticket queued in this frontend build. Connect the API to persist it.')">Create ticket</button></div></div></main>`
}
function profilePage(){return `<main class="container"><div class="card"><h1>Profile</h1><p>${esc(state.user?.fullName||'Guest')}</p><p class="muted">${esc(state.user?.email||'Not signed in')}</p></div></main>`}

function adminPage(){
 if(state.user?.role!=='ADMIN')return `<main class="container"><div class="card"><h1>Admin</h1><p>Administrator access required.</p><button class="btn primary" onclick="authModal('login')">Login</button></div></main>`;
 return `<main class="container"><div class="card"><h1>WexatP2P Admin Control Center</h1><p class="muted">Central operations: users, KYC, offers, trades, disputes, payments, fees, risk, settings and audit.</p><div class="adminbar">${['Overview','Users','KYC','Offers','Trades','Disputes','Payments','Fees','Risk / AML','Settings','Audit Logs'].map(x=>`<button onclick="adminSection('${x}')">${x}</button>`).join('')}</div><div id="adminContent" class="section"></div></div></main>`
}
function adminSection(s){
 const el=document.getElementById('adminContent'); if(!el)return;
 const rows={Overview:`<div class="grid4">${[['Users','—'],['KYC','—'],['Offers',sampleOffers.length],['Trades',state.trades.length]].map(x=>`<div class="card"><div class="muted">${x[0]}</div><div class="stat">${x[1]}</div></div>`).join('')}</div>`,
 Users:`<div class="notice">User management: activate, suspend, lock, role/permission review and account history.</div>`,
 KYC:`<div class="notice warning">KYC queue: SUBMITTED → PROVIDER_PENDING → MANUAL_REVIEW → VERIFIED/REJECTED. Real provider adapter required.</div>`,
 Offers:`${offerRows()}`,
 Trades:`${tradesPage()}`,
 Disputes:`<div class="notice dangerbox">Dispute queue with evidence, assignment, decision, resolution note and audit trail.</div>`,
 Payments:`<div class="notice">Payment operations must use signed webhooks and idempotency keys.</div>`,
 Fees:`<div class="grid"><div class="field"><label>Buyer fee %</label><input value="0.50"></div><div class="field"><label>Seller fee %</label><input value="0.50"></div></div><button class="btn primary" onclick="toast('Fee settings saved in UI; persist through secured admin API in production.')">Save fees</button>`,
 'Risk / AML':`<div class="notice warning">Velocity, identity, payment, sanctions and account-history risk should be evaluated server-side.</div>`,
 Settings:`<div class="grid"><div class="field"><label>Platform name</label><input value="WexatP2P"></div><div class="field"><label>Maintenance mode</label><select><option>OFF</option><option>ON</option></select></div></div>`,
 'Audit Logs':`<div class="notice">Every privileged action should be immutable and traceable.</div><pre>${esc(JSON.stringify(state.trades.map(t=>({action:'TRADE_CREATED',id:t.id,time:t.createdAt})),null,2))}</pre>`}[s]||'<div class="notice">Select a module.</div>';
 el.innerHTML=rows
}

function render(){
 state.route=location.hash.replace('#','')||'home';
 let body= state.route==='home'?home():
 state.route==='buy'?marketplace('SELL'):
 state.route==='sell'?marketplace('BUY'):
 state.route==='offers'?offersPage():
 state.route==='trades'?tradesPage():
 state.route==='wallet'?walletPage():
 state.route==='kyc'?kycPage():
 state.route==='security'?securityPage():
 state.route==='support'?supportPage():
 state.route==='profile'?profilePage():
 state.route==='admin'?adminPage():
 home();
 document.getElementById('app').innerHTML=nav()+body+`<footer class="footer"><div class="container">WexatP2P · Secure P2P marketplace foundation · Do not send private keys or National ID documents through public GitHub.</div></footer>`;
 if(state.route==='admin')setTimeout(()=>adminSection('Overview'),0)
}
window.addEventListener('hashchange',render);window.addEventListener('load',render);

function authModal(mode){
 const signup=mode==='signup';
 document.body.insertAdjacentHTML('beforeend',`<div class="modal" id="modal"><div class="modalbox card"><button class="close" onclick="closeModal()">×</button><h2>${signup?'Create account':'Login'}</h2>${signup?`<div class="field"><label>Full name</label><input id="fullName"></div>`:''}<div class="field"><label>Email</label><input id="email" type="email"></div><div class="field"><label>Password</label><input id="password" type="password"></div><button class="btn primary" onclick="${signup?'signup()':'login()'}">${signup?'Create account':'Login'}</button><div id="authMsg"></div></div></div>`)
}
function closeModal(){document.getElementById('modal')?.remove()}
async function signup(){
 try{const fullName=document.getElementById('fullName').value,email=document.getElementById('email').value,password=document.getElementById('password').value;const x=await api('/auth/signup',{method:'POST',body:JSON.stringify({fullName,email,password})});state.user=x.user;state.user.token=x.token;save();closeModal();render();toast('Account created. Complete KYC before restricted features.')}
 catch(e){document.getElementById('authMsg').innerHTML=`<div class="notice dangerbox">${esc(e.message)}</div>`}
}
async function login(){
 try{const email=document.getElementById('email').value,password=document.getElementById('password').value;const x=await api('/auth/login',{method:'POST',body:JSON.stringify({email,password})});state.user=x.user;state.user.token=x.token;save();closeModal();render()}
 catch(e){document.getElementById('authMsg').innerHTML=`<div class="notice dangerbox">${esc(e.message)}</div>`}
}
function logout(){state.user=null;save();go('home')}
function applyFilters(){state.filters.asset=document.getElementById('assetFilter').value;state.filters.paymentMethod=document.getElementById('paymentFilter').value;loadOffers().then(render)}
function startTrade(id){
 if(!state.user)return authModal('login');
 const o=[...state.offers,...sampleOffers].find(x=>x.id===id);if(!o)return;
 const amount=Math.min(o.available,Math.max(o.min,Number(prompt(`Amount in ${o.fiat}`,o.min)||0)));
 if(!amount||amount<o.min||amount>o.max)return toast('Amount is outside offer limits.');
 const assetAmount=amount/o.price;const fee=amount*.005;
 const t={id:`TR-${Date.now()}`,offerId:o.id,asset:o.asset,assetAmount,tradeValue:amount,buyerId:state.user.id||'local',sellerId:o.owner,status:'CREATED',createdAt:new Date().toISOString()};
 state.trades.unshift(t);save();go('trades');toast(`Trade created. Buyer fee estimate: ${money(fee)}`)
}
function advanceTrade(id,status){const t=state.trades.find(x=>x.id===id);if(!t)return;t.status=status;save();render();toast(`Trade ${id} → ${status}`)}
function openDispute(id){const reason=prompt('Describe the dispute');if(!reason)return;toast(`Dispute recorded locally for ${id}. Connect API to persist and assign it.`)}
function offerModal(){toast('Offer creation form is ready for API persistence in the backend.')}
function kycModal(){toast('KYC submission requires backend/provider configuration; browser will never self-verify an ID.')}
function toast(msg){const d=document.createElement('div');d.className='modal';d.innerHTML=`<div class="card modalbox"><h3>WexatP2P</h3><p>${esc(msg)}</p><button class="btn primary" onclick="this.closest('.modal').remove()">OK</button></div>`;document.body.appendChild(d)}
